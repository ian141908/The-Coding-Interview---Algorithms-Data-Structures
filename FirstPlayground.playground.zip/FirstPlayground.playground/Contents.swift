import UIKit

var str = "Hello, playground"

func Reversed(word: String) {
    for char in word.reversed() {
        print(char, terminator: "")
    }
}

Reversed(word: "Hello World!")

func RemasteredReversed(word: String) -> String {
    var reversed: String = ""
    
    for counter in word.reversed(){
        reversed.append(counter)
    }
    print("\n\(reversed)")
    return reversed
}

RemasteredReversed(word: "Alaska")

func Palindromes(word: String) -> Bool {
    var reversed: String = ""
    
    for counter in word.reversed(){
        reversed.append(counter)
    }
    
    let newReversed = reversed.lowercased()
    let remasteredReversed = newReversed.replacingOccurrences(of: " ", with: "")
    
    let newWord = word.lowercased()
    let remasteredWord = newWord.replacingOccurrences(of: " ", with: "")
    
    if remasteredReversed == remasteredWord {
        return true
    }
    else {
        return false
    }
}

Palindromes(word: "Anita lava la tina")

func ReversedNumbers(numbers: Int) -> Int {
    var reversed: String = ""
    
    if numbers.signum() == -1 {
        
        let positiveNumbers = numbers * -1
        let word = String(positiveNumbers)
        
        for counter in word.reversed(){
            reversed.append(counter)
        }
        
        let negativeReversed = (Int(reversed) ?? 0) * numbers.signum()
        print("\n\(negativeReversed)")
        return negativeReversed
    }
    
    let word = String(numbers)
    
    for counter in word.reversed(){
        reversed.append(counter)
    }
    print("\n\(reversed)")
    return Int(reversed) ?? 0
}

ReversedNumbers(numbers: 282829140034)


func MostCommonCharacters (word: String) {
    var charMap: [String: Int] = [:]
    var max = 0
    var maxChar = ""
    var maxDictionary:[String: Int] = [:]
    
    for char in word {
        let originalChar = String(char).lowercased().replacingOccurrences(of: " ", with: "")
        if (charMap[originalChar] != nil) {
            let counter = charMap[originalChar] ?? 0
            charMap.updateValue(counter + 1, forKey: originalChar)
        } else {
            charMap[originalChar] = 1
        }
    }
    print(charMap)
    
    for char in word {
        let originalChar = String(char).lowercased().replacingOccurrences(of: " ", with: "")
        if charMap[originalChar] ?? 0 >= max {
            max = charMap[originalChar] ?? 0
            maxChar = originalChar
        }
        maxDictionary[maxChar] = max
    }
    print(maxDictionary)
}

MostCommonCharacters(word: "JEJEJEJEJE")

func FizzBuzz (n: Int) {
    
    for i in 1...n {
        if i % 3 == 0 && i % 5 == 0 {
            print("FizzBuzz")
        } else if i % 3 == 0 {
            print("fizz")
        } else if i % 5  == 0 {
            print("buzz")
        } else {
            print(i)
        }
    }
}

FizzBuzz(n: 300)

func chunk (array: [Any], size: Int)  {
    var chuncked: [Any] = []
    var index = 0
    
    while (index <= (array.count-1)) {
        if (index+(size)) <= (array.count-1) {
            let slice = array[index...index+(size-1)]
            let realArray = Array(slice)
            //print(realArray)
            chuncked.append(realArray)
            index += size
        } else {
           /* print("I am in")
            print(index-1)
            print(array.endIndex-1) */
            let slice = array[(index)...(array.endIndex-1)]
            let realArray = Array(slice)
            chuncked.append(realArray)
            index += size
        }
    }
    print(chuncked)
}

chunk(array: [1,2,3,13,1,1,4,122,1,1,1,2,2,3,4,5,1,2,2,1,4,5,6], size: 4)


func BuildCharMap(str: String) -> [String: Int] {
    var charMap: [String: Int] = [:]
    let withoutSpacesStr = PlaneWords(word: str)
    
    for char in withoutSpacesStr {
        let originalChar = String(char)
        if (charMap[originalChar] != nil) {
            let counter = charMap[originalChar] ?? 0
            charMap.updateValue(counter + 1, forKey: originalChar)
        } else {
            charMap[originalChar] = 1
        }
    }
    print(charMap)
    return charMap
}

BuildCharMap(str: "Hey que onda carnalito!!!")


func PlaneWords (word: String) -> String {
    let originalChar = word.lowercased()
    //    let regexString = NSMutableString(string: originalChar)
    //    let regex = try! NSRegularExpression(pattern: "/[^\\w]/g")
    //    let range = NSRange(location: 0, length: originalChar.utf16.count)
    //
    //    let withoutSpacesStrSupposed = regex.stringByReplacingMatches(in: originalChar, options: .reportProgress, range: range, withTemplate: "")
    //    print("Hey probando papá \(withoutSpacesStrSupposed)")
    
    let withoutSpacesStr = originalChar.replacingOccurrences(of: " ", with: "").replacingOccurrences(of: "!", with: "")
    return withoutSpacesStr
}

PlaneWords(word: "Hey que onda papa tambien tu no te pases jefe!!!!")


func anagrams (firstWord: String, secondWord: String) -> Bool {
    
    let aCharMap = BuildCharMap(str: firstWord)
    let bCharMap = BuildCharMap(str: secondWord)
    
    let aPlaneWord = PlaneWords(word: firstWord)
    
    if aCharMap.count != bCharMap.count {
        return false
    }

    for char in aPlaneWord {
        let originalWord = String(char)
        if aCharMap[originalWord] != bCharMap[originalWord] {
            return false
        }
    }
    return true
}

anagrams(firstWord: "The eyes!!!", secondWord: "They see")

extension StringProtocol {
    subscript(offset: Int) -> Character { self[index(startIndex, offsetBy: offset)] }
    subscript(range: Range<Int>) -> SubSequence {
        let startIndex = index(self.startIndex, offsetBy: range.lowerBound)
        return self[startIndex..<index(startIndex, offsetBy: range.count)]
    }
    subscript(range: ClosedRange<Int>) -> SubSequence {
        let startIndex = index(self.startIndex, offsetBy: range.lowerBound)
        return self[startIndex..<index(startIndex, offsetBy: range.count)]
    }
    subscript(range: PartialRangeFrom<Int>) -> SubSequence { self[index(startIndex, offsetBy: range.lowerBound)...] }
    subscript(range: PartialRangeThrough<Int>) -> SubSequence { self[...index(startIndex, offsetBy: range.upperBound)] }
    subscript(range: PartialRangeUpTo<Int>) -> SubSequence { self[..<index(startIndex, offsetBy: range.upperBound)] }
 
}

func Capitalize(str: String) -> String {
    var counter = 0
    var result = str[0].uppercased()
    var newCounter = 0

    for element in str {
        if str[counter] == " " {
            result.append(" ")
            let newStr = str[counter + 1].uppercased()
            result.append(newStr)
        } else if str[newCounter] == " " {
            
        } else {
            result.append(element)
        }
        newCounter = counter
        counter += 1
    }
    
    if let index = result.index(result.startIndex, offsetBy: 1, limitedBy: result.endIndex) {
        result.remove(at: index)
    }
     
    print(result)
    print(counter)
    
    return result
}

Capitalize(str: "no importa en realidad que pongas la verdad siempre funcionara, papa")

let str3 = "Andrew, Ben, John, Paul, Peter, Laura"
let array = str3.components(separatedBy: ", ")
print(array)







//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

struct Person {
    let name: String
    let address: String
    let age: Int
    let income: Double
    let cars: [String]?
}

let peopleArray = [ Person(name:"Santosh", address: "Pune, India", age:34, income: 100000.0, cars:["i20","Swift VXI"]),
                    Person(name: "John", address:"New York, US", age: 23, income: 150000.0, cars:["Crita", "Swift VXI"]),
                    Person(name:"Amit", address:"Nagpure, India", age:17, income: 200000.0, cars:Array())]

// Approach 0
var name: [String] = Array()

for person in peopleArray {
    name.append(person.name)
}
print(name)
// Result- ["Santosh", "John", "Amit"]

// Approach 1
let names = peopleArray.map({ (person) -> String in
    return person.name
})
print(names)
// Result: ["Santosh", "John", "Amit"]

// Approach 2
let personNames = peopleArray.map({ $0.name })
print(personNames)
// Result: ["Santosh", "John", "Amit"]

let cars = peopleArray.map({ $0.cars })
print(cars)
// Result: [["i20", "Swift VXI"], ["Crita", "Swift VXI"], []]

let movieCars = peopleArray.map({ $0.age})
print(movieCars)

// flatMap
let flatCars = peopleArray.compactMap({ $0.cars }).flatMap{ $0 }
print("Flatmap: \(flatCars)")

// Result: Flatmap: ["i20", "Swift VXI", "Crita", "Swift VXI"]

//Filter

let filteredNames = peopleArray.filter( {$0.age > 18 }).compactMap({ $0.cars}).flatMap{ $0 }
print(filteredNames)
// Result: ["Santosh", "John"]

//Reduce

//Approach 1
let totalIncome = peopleArray.reduce(0) {(result, next) -> Double in
    return result + next.income
}

print("Total Income: \(totalIncome) Average Income: \(totalIncome/Double(peopleArray.count))")
//Result: Total Income: 450000.0 Average Income: 150000.0

// Example 2:
let numbers = [23.23478, -2.32784, 34.328, 33.28347]
let sum = numbers.reduce(0) { (result, next) -> Double in
    return result + next
}
print("Sum: \(sum)")

// More concise code
let conciseSum = numbers.reduce(0, +)
print("conciseSum: \(conciseSum)")

let flatmapArray2 = peopleArray.map({($0.cars ?? Array())}).reduce([], +)
print("flatmapArray2 : \(flatmapArray2)")



//Closures

var completionHandlers = [() -> Void]()

func someFunctionWithEscapingClosure(completionHandler: @escaping () -> Void) {
    completionHandlers.append(completionHandler)
}

func someFunctionWithNonescapingClosure(closure: () -> Void) {
    closure()
}

class SomeClass {
    var x = 10
    func doSomething() {
        someFunctionWithEscapingClosure { self.x = 100 }
        someFunctionWithNonescapingClosure { x = 200 }
    }
}

let instance = SomeClass()
instance.doSomething()
print(instance.x)
// Prints "200"

completionHandlers.first?()
print(instance.x)
// Prints "100"

let simpleClosure = {
    print("Hello, World!")
}
simpleClosure()

let simpleClosure2:(String) -> () = { name in
    print(name)
}
simpleClosure2("Hello, World")

let driving = {
    print("I'm driving in my car")
}

func travel(action: () -> Void) {
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}
travel(action: driving)

let simpleClosure3:(String) -> (String) = { name in
    
    let greeting = name + "Program"
    return greeting
}

let result = simpleClosure3("You are my creation ")
print(result)

/* Example 4: Passing Closures as a function parameter
 We can also pass closure as a parameter to a function as: */

func someSimpleFunction(someClosure:()->()) {
    
    print("Function Called")
    someClosure()
}

someSimpleFunction(someClosure: {
    print("Hello World! from closure")
})

// Example 5: Trailing closure

func someSimpleFunction(msg:String, someClosure:()->()) {
    print(msg)
    someClosure()
}

someSimpleFunction(msg:"We are really exciting about the potential related with Bio-tech")  {
    print("Hello World! from GDL Jalisco")
}

//AutoClosure


// Initialize the Dictionary
var dict = ["name": "John", "surname": "Doe"]
 
// Add a new key with a value

dict["email"] = "john.doe@email.com"

print(dict)

func viewDidLoad() {
    print("Step 1")
    myFunc()
    print("Step 5")
}

func myFunc() {
    defer { print("Step 3") }
    print("Step 2")
    print("Step 4")
}

func anotherScenarioToTestDeffer() {
    for i in 1...10 {
        print ("In \(i)")
        defer { print ("Deferred \(i) asi es third place papa") }
        defer { print ("Deferred \(i)") }
        defer { print ("Deferred \(i) asi es second place papa") }
    
        print ("Out \(i)")
    }
}

viewDidLoad()
anotherScenarioToTestDeffer()

extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var addedDict = [Element: Bool]()

        return filter {
            addedDict.updateValue(true, forKey: $0) == nil
        }
    }

    mutating func removeDuplicates() {
        self = self.removingDuplicates()
    }
}

let Radioheadnumbers = [1, 5, 3, 4, 5, 1, 3]
let unique = Radioheadnumbers.removingDuplicates()

func split(name: String) -> (firstName: String, lastName: String) {
    let split = name.components(separatedBy: " ")
    return (split[0], split[1])
}

let parts = split(name: "Paul Hudson")
parts.0
parts.1
parts.firstName
parts.lastName

var tuple = (firstName: "Hello", lastName: "World", heyPachuco: "yex yex yex yex en inglex", hello:2)
tuple.3

func getFullName() -> String {
    let fullName = "John Trump"
    return fullName
}

let myFullName = getFullName()

print(myFullName)

var s = "Hello, I must be going"
var n = 5
if let index = s.index(s.startIndex, offsetBy: n, limitedBy: s.endIndex) {
    s.remove(at: index)
    print(s) // prints "Hello I must be going"
} else {
    print("\(n) is out of range")
}
